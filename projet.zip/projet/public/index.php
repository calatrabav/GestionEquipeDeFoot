<?php
// Inclure les fichiers nécessaires
require_once "../controllers/AuthController.php";
require_once "../controllers/JoueursController.php";
require_once "../controllers/MatchsController.php";

// Récupérer les paramètres dans l'URL
$controller = $_GET['controller'] ?? 'auth'; // Contrôleur par défaut : auth
$action = $_GET['action'] ?? 'login'; // Action par défaut : login

// Gestion des contrôleurs
switch ($controller) {
    case 'auth':
        $controller = new AuthController();
        break;
    case 'joueurs':
        $controller = new JoueursController();
        break;
    case 'matchs':
        $controller = new MatchsController();
        break;
    default:
        die("Contrôleur inconnu !");
}

// Exécuter l'action
if (method_exists($controller, $action)) {
    $controller->$action();
} else {
    die("Action inconnue !");
}
?>

<nav>
    <ul>
        <!-- Lien vers la gestion des joueurs -->
        <li><a href="index.php?controller=joueurs&action=index">Gestion des Joueurs</a></li>
        
        <!-- Lien vers la gestion des matchs -->
        <li><a href="index.php?controller=matchs&action=index">Gestion des Matchs</a></li>
        
        <!-- Lien vers les statistiques (si implémentées) -->
        <li><a href="index.php?controller=statistiques&action=index">Statistiques</a></li>
        
        <!-- Lien pour déconnexion -->
        <li><a href="index.php?controller=auth&action=logout">Se Déconnecter</a></li>
    </ul>
</nav>
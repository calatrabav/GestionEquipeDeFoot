<?php include "../includes/menu.php"; ?>

<h1>Modifier un Match</h1>
<form method="POST" action="index.php?controller=matchs&action=modifier&id=<?= $match['idMatch'] ?>">
    <label>Date :</label><input type="date" name="dateMatch" value="<?= $match['dateMatch'] ?>" required><br>
    <label>Heure :</label><input type="time" name="heureMatch" value="<?= $match['heureMatch'] ?>" required><br>
    <label>Lieu :</label><input type="text" name="lieuRencontre" value="<?= $match['lieuRencontre'] ?>" required><br>
    <label>Équipe Adverse :</label><input type="text" name="nomEquipeAdverse" value="<?= $match['nomEquipeAdverse'] ?>" required><br>
    <button type="submit">Modifier</button>
</form>

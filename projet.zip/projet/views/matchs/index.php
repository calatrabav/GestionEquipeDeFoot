<?php include "../includes/menu.php"; ?>

<h1>Liste des Matchs</h1>
<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Heure</th>
            <th>Lieu</th>
            <th>Équipe Adverse</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($matchs as $match): ?>
        <tr>
            <td><?= $match['dateMatch'] ?></td>
            <td><?= $match['heureMatch'] ?></td>
            <td><?= $match['lieuRencontre'] ?></td>
            <td><?= $match['nomEquipeAdverse'] ?></td>
            <td>
                <a href="index.php?controller=matchs&action=modifier&id=<?= $match['idMatch'] ?>">Modifier</a> |
                <a href="index.php?controller=matchs&action=supprimer&id=<?= $match['idMatch'] ?>">Supprimer</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<a href="index.php?controller=matchs&action=ajouter">Ajouter un match</a>

<?php include "../includes/menu.php"; ?>

<?php include 'includes/header.php'; ?>
<h1>Liste des joueurs</h1>
<a href="index.php?controller=joueurs&action=ajouter">Ajouter un joueur</a>
<table border="1">
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Statut</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($joueurs as $joueur): ?>
    <tr>
        <td><?= htmlspecialchars($joueur['nomJoueur']) ?></td>
        <td><?= htmlspecialchars($joueur['prenomJoueur']) ?></td>
        <td><?= htmlspecialchars($joueur['statut']) ?></td>
        <td>
            <a href="index.php?controller=joueurs&action=modifier&id=<?= $joueur['idJoueur'] ?>">Modifier</a>
            <a href="index.php?controller=joueurs&action=supprimer&id=<?= $joueur['idJoueur'] ?>" onclick="return confirm('Confirmer ?')">Supprimer</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php include 'includes/footer.php'; ?>
